# Artigo ICA — Template SBPO 2025 sem modificações estéticas

Este projeto foi criado DIRETAMENTE a partir de `Template_SBPO2025_LaTeX_ptbr.zip`.

## Fidelidade ao template
- `sbpo-template.sty`, `sbpo.bst` e `sbpo2025-header-logo.png` permanecem **inalterados**.
- O preâmbulo de `exemplo-latex.tex` foi preservado, com o encoding do artigo atualizado para UTF-8 para exibir corretamente os caracteres acentuados.
- Foram mantidos os comandos `\\maketitle`, `\\author`, `\\name`, `\\institute`, `\\iaddress`, `\\email`, `resumo`, `palchaves`, `abstract`, `keywords`, seus espaçamentos originais e o `\\newpage` antes da Introdução.
- Alterou-se apenas o título, o texto dentro dos ambientes e o conteúdo científico após a primeira página.
- O artigo tem um único autor: Rhaiany Souza, da Universidade Federal Fluminense — PPG-MCCT, na disciplina Inteligência Computacional Aplicada (ICA).
- O mesmo vale para a linha 'Tópicos' e 'Paper topics', mantidas exatamente como campos do modelo para seleção dos tópicos oficiais.

## Arquivos
- `artigo_sbpo2025.tex`: texto-fonte editável.
- `artigo_sbpo2025.pdf`: saída compilada.
- `referencias.bib`: referências do artigo.
- `artigo_sbpo2025.bbl`: bibliografia compilada, incluída para permitir compilação mesmo sem BibTeX.
- `exemplo-latex.tex`, `exemplo-latex.bib`, `sbpo-template.sty`, `sbpo.bst`, `sbpo2025-header-logo.png`: arquivos originais do ZIP, intactos.

## Compilar
No Overleaf: selecione `artigo_sbpo2025.tex` como arquivo principal; compilador pdfLaTeX. O formato do arquivo fonte é UTF-8. A bibliografia usa o estilo `sbpo.bst` original.

## Nota científica
As equações descritas são da versão experimental simplificada do protótipo, não são cópias integrais das equações de Rabbani et al. (2018). A comparação e as limitações estão explicitadas no artigo.
